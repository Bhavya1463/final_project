#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

int main()
{
    char str[50];
    scanf("%s",str);
    //printf("%s",str);

    char *stack=(char *)malloc(sizeof(char)*strlen(str));
    int x=-1;

    for(int i=0;i<strlen(str);i++)
    {
        if(i==0)
        {
            stack[++x]=str[i];
        }
        else{
            if(stack[x]==str[i])
            {
                x--;
            }
            else{
                stack[++x]=str[i];
            }
        }

    }
    if(x==-1)
        {
            printf("Empty String");
        }
        else
        {
            for(int i=0;i<=x;i++)
            {
                printf("%c",stack[i]);
            }
        }
        return 0;
}