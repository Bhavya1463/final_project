#include<stdio.h>
#include<stdlib.h>
void reverseBits(int num[],int length)
{
    int si=32-length;
    int ei=31;
    while(si<=ei)
    {
        int t=num[si];
        num[si]=num[ei];
        num[ei]=t;
        si++;
        ei--;
    }
    for(int i=32-length;i<32;i++)
    {
        printf("%d",num[i]);
    }
    printf("\n");
}
int main()
{
    int num;
    scanf("%d",&num);
    if(num<0)
        printf("Not possible since unsigned given in question\n");
    int ind=31;
    int arr[32]={0}; //unsigned int is 32 bit
    while(num!=0)
    {
        if(num %2== 1)
            arr[ind]=1;
        else 
            arr[ind]=0;
        num=num/2;
        ind--;
    }
    int startInd;
    for(int i=0;i<32;i++)
    {
        if(arr[i]==1)
        {
            startInd=i;
            break;
        }
    }
    unsigned int ans=0;
    int temp=startInd;
    while(temp<32)
    {
        ans=ans*10;
        ans+=arr[temp];
        temp++;
    }
    int length=32-startInd;
    printf("%d\n",ans);
    reverseBits(arr,length);
    return 0;
}