#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int n=5;
char name[20];

struct relation{
char child[20];
char father[20];
}r[10];

int count= -1;
void countChildren(char name[])
    {
    int j;
    for(j=0;j<n;j++)
        {
        if(strcmp(name,r[j].father)==0)
            {
            count++;
            countChildren(r[j].child);
            }
        }
    }

void main()
{
int i;
FILE *fptr;
fptr=fopen("file.txt","r");
for(i=0;i<n;i++)
    {
    fscanf(fptr,"%s",r[i].child);
    fscanf(fptr,"%s",r[i].father);
    }
scanf("%s",name);
for(i=0;i<n;i++)
    {
    if(strcmp(r[i].father,name)==0)
        countChildren(r[i].child);
    }
printf("\n%d\n",(count-1));
}
